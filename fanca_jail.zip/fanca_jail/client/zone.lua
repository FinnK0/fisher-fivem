local zone = nil
local outsideTheZone = false

function isPlayerInPrisonZone()
    return zone and zone:contains(GetEntityCoords(cache.ped)) or false
end
lib.callback.register('fanca_jail:isPlayerInPrisonZone', isPlayerInPrisonZone)

function setPlayerOutsideTheZone(bool)
    outsideTheZone = bool

    if outsideTheZone then
        CreateThread(function()
            while zone and outsideTheZone do
                local waitTime = isPlayerInPrisonZone() and 5000 or 1000

                if not isPlayerInPrisonZone() then
                    local distance = #(GetEntityCoords(cache.ped) - Config.prisonCenterPoint)
                    local isUnJailDistance = distance > Config.unJailDistance

                    if isUnJailDistance then
                        TriggerServerEvent("fanca_jail:escaped")
                    end
                end

                Wait(waitTime)
            end
        end)
    end
end

function createZone()
    zone = lib.zones.poly({
        name = "Prison",
        points = Config.prisonPoints,
        thickness = 50.0,
        debug = Config.debug,
        onEnter = function(self)
            setPlayerOutsideTheZone(false)
        end,
        onExit = function(self)
            setPlayerOutsideTheZone(true)
        end
    })

    Wait(2500)
    setPlayerOutsideTheZone(not isPlayerInPrisonZone())
end

function deleteZone()
    if zone then
        zone:remove()
        zone = nil
    end
    setPlayerOutsideTheZone(false)
end

AddEventHandler('onResourceStop', function(resourceName)
    if cache.resource ~= resourceName then return end
    deleteZone()
end)

AddEventHandler('esx:onPlayerLogout', deleteZone)