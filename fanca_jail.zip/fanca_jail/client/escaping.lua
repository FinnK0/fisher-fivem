local blips = {}

local function createBlip(targetId, targetName, coords)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipColour(blip, 29)
    SetBlipScale(blip, 0.5)
    SetBlipSprite(blip, 4)
    SetBlipCategory(blip, 2)
    SetBlipPriority(blip, 10)
    SetBlipShrink(blip, true)
    ShowHeightOnBlip(blip, false)
    SetBlipFlashes(blip, true)
    SetBlipFlashInterval(blip, 500)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(targetName)
    EndTextCommandSetBlipName(blip)
    blips[tostring(targetId)] = blip
end

local function updateBlipPosition(targetId, coords)
    local blip = blips[tostring(targetId)]
    if blip then
        SetBlipCoords(blip, coords.x, coords.y, coords.z)
    end
end

local function removeBlipById(targetId)
    local blip = blips[tostring(targetId)]
    if blip then
        RemoveBlip(blip)
        blips[tostring(targetId)] = nil
    end
end

local function removeAllBlips()
    for k, v in pairs(blips) do
        removeBlipById(k)
    end
end

RegisterNetEvent("fanca_jail:addEscaping", function(targetId, targetName, coords)
    if lib.table.contains(Config.jobName, ESX.PlayerData.job.name) then
        createBlip(targetId, targetName, coords)
    end
end)

RegisterNetEvent("fanca_jail:updatePosition", function(targetId, coords)
    if lib.table.contains(Config.jobName, ESX.PlayerData.job.name) then
        updateBlipPosition(targetId, coords)
    end
end)

RegisterNetEvent("fanca_jail:removeEscaping", function(targetId)
    if lib.table.contains(Config.jobName, ESX.PlayerData.job.name) then
        removeBlipById(targetId)
    end
end)

RegisterNetEvent('esx:setJob', function(job)
    ESX.PlayerData.job = job
    if not lib.table.contains(Config.jobName, job.name) then
        removeAllBlips()
    end
end)

AddEventHandler('esx:onPlayerLogout', removeAllBlips)