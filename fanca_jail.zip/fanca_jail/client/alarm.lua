local alarmInteriorName = "int_prison_main"
local alarmPropName = "prison_alarm"
local alarmIplCoords = vector3(1787.004, 2593.1984, 45.7978)

local function getAlarmInterior()
    return GetInteriorAtCoordsWithType(alarmIplCoords.x, alarmIplCoords.y, alarmIplCoords.z, alarmInteriorName)
end

local function refreshInteriorProps(alarmIpl)
    RefreshInterior(alarmIpl)
end

local function setAlarmState(state)
    local alarmIpl = getAlarmInterior()

    if alarmIpl ~= 0 then
        refreshInteriorProps(alarmIpl)

        if state then
            EnableInteriorProp(alarmIpl, alarmPropName)
            Citizen.CreateThread(function()
                while not PrepareAlarm("PRISON_ALARMS") do
                    Citizen.Wait(100)
                end
                StartAlarm("PRISON_ALARMS", true)
            end)
        else
            DisableInteriorProp(alarmIpl, alarmPropName)
            Citizen.CreateThread(function()
                while not PrepareAlarm("PRISON_ALARMS") do
                    Citizen.Wait(100)
                end
                StopAllAlarms(true)
            end)
        end
    end
end

Citizen.CreateThread(function()
    setAlarmState(false) -- Stopping the alarm on script start
end)

AddStateBagChangeHandler("fanca_jail:alarm", "", function(_, _, alarmState)
    Debug(("Prison alarm state changed: %s"):format(alarmState))
    setAlarmState(alarmState)
end)