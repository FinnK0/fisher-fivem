function setAlarm(state)
    GlobalState:set("fanca_jail:alarm", state, true)
end
exports('setAlarm', setAlarm)

Citizen.CreateThreadNow(function()
    setAlarm(false)
end)