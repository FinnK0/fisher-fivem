local pcall = pcall
local type = type
local tonumber = tonumber
local pairs = pairs
local next = next

local AUTOSAVE = Config.autoSave * 60 * 1000
local ESCAPETIME = Config.escapeTime * 60 * 1000
local ALARMDURATIONWHENESCAPE = Config.alarmDurationWhenEscape * 60 * 1000

Citizen.CreateThreadNow(function()
    local success, result = pcall(MySQL.scalar.await, 'SELECT jail_time, jail_escaping FROM users')

    if not success then
        MySQL.query([[
            ALTER TABLE users ADD COLUMN IF NOT EXISTS jail_time INT(11) NOT NULL DEFAULT '0';
        ]])
        MySQL.query([[
            ALTER TABLE users ADD COLUMN IF NOT EXISTS jail_escaping TINYINT(1) NULL DEFAULT '0';
        ]])
        Debug("The server database was not configured well, I automatically made the changes necessary for my operation.")
    end

    while true do
        Citizen.Wait(1000)

        for identifier, data in pairs(JailCache) do
            if data.seconds > 0 then
                JailCache[identifier].seconds = data.seconds - 1
            else
                unJail(identifier)
            end
        end
    end
end)

Citizen.CreateThreadNow(function()
    while true do
        Citizen.Wait(AUTOSAVE)
        savePlayers()
    end
end)

function GetPlayersOfJobs()
    local xPlayers = {}
    for _,v in pairs(Config.jobName) do
        local xPlayersJob = ESX.GetExtendedPlayers('job', v)
        lib.table.merge(xPlayers, xPlayersJob)
    end

    return xPlayers
end

function setJailTime(playerId, seconds, dontSave)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if not xPlayer then return end

    local identifier = xPlayer.getIdentifier()

    if type(seconds) ~= "number" or seconds <= 0 then
        unJail(identifier)
        return
    end

    if EscapingCache[identifier] then
        setEscaping(playerId, 0)
    end

    playerIdentifiers[xPlayer.playerId] = identifier

    if not JailCache[identifier] then
        JailCache[identifier] = {
            playerId = playerId,
            seconds = seconds
        }

        lib.callback('fanca_jail:jail', playerId, function()
            Debug(("Player %s (%s) is now jailed for %s seconds."):format(identifier, playerId, seconds))

            if not dontSave then
                SetEntityCoords(GetPlayerPed(playerId), Config.jailSpawnpointCoords.x, Config.jailSpawnpointCoords.y, Config.jailSpawnpointCoords.z, 0,0,0, false)
            end
        end, seconds)
    else
        JailCache[identifier].seconds = seconds
        lib.callback('fanca_jail:setJailTime', xPlayer.playerId, function()
            Debug(("Updated the client seconds of %s (%s) to %s seconds."):format(identifier, playerId, seconds))
        end, seconds)
    end

    if not dontSave then
        savePlayer(identifier)
    end
end
exports('setJailTime', setJailTime)

function setEscaping(playerId, state, dontSave)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if not xPlayer then return end

    local identifier = xPlayer.getIdentifier()
    if JailCache[identifier] then
        unJail(identifier, true)
    end

    if state and not EscapingCache[identifier] then
        EscapingCache[identifier] = {
            playerId = playerId
        }

        setAlarm(true)
        SetTimeout(ALARMDURATIONWHENESCAPE, function ()
            if not next(EscapingCache) then
                setAlarm(false)
            end
        end)

        xPlayer.triggerEvent("fanca_jail:notify", {type = "warning",position = 'center-right', description = "Je bent op de vlucht..."})

        local coords = GetEntityCoords(GetPlayerPed(playerId))
        local messageNotify = ("%s is uitgebroken uit de gevangenis, kijk op je gps waar die zich bevind."):format(Player(playerId).state.name)

        for _, xPlayerJob in pairs(GetPlayersOfJobs()) do
            xPlayerJob.triggerEvent("fanca_jail:addEscaping", playerId, Player(playerId).state.name, coords)
            xPlayerJob.triggerEvent("fanca_jail:notify", {type = "warning",position = 'center-right', description = messageNotify})
        end
        --------------------------------------------------------------------------------------------------------
        -- For testing
        -- local xPlayers = ESX.GetPlayers()
        -- for i=1, #xPlayers do
        --     Wait(100)
        --     local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        --     xPlayer.triggerEvent("fanca_jail:addEscaping", playerId, Player(playerId).state.name, coords)
        -- end
        --------------------------------------------------------------------------------------------------------

        Citizen.CreateThread(function()
            local frequency = Config.blipEscapingFrequency * 1000
            while EscapingCache[identifier] do
                local playerPed = GetPlayerPed(playerId)
                local playerCoords = GetEntityCoords(playerPed)

                for _, xPlayerJob in pairs(GetPlayersOfJobs()) do
                    xPlayerJob.triggerEvent("fanca_jail:updatePosition", playerId, playerCoords)
                end

                --------------------------------------------------------------------------------------------------------
                -- For testing
                -- local xPlayers = ESX.GetPlayers()
                -- for i=1, #xPlayers do
                --     local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
                --     xPlayer.triggerEvent("fanca_jail:updatePosition", playerId, playerCoords)
                -- end
                --------------------------------------------------------------------------------------------------------

                Citizen.Wait(frequency)
            end
        end)

        SetTimeout(ESCAPETIME, function()
            if EscapingCache[identifier] then
                setEscaping(playerId, 0)
            end
        end)

        Debug(("The player %s (%s) is escaping from the prison."):format(identifier, playerId))
    else
        EscapingCache[identifier] = nil

        if not next(EscapingCache) then
            setAlarm(false)
        end

        for _, xPlayerJob in pairs(GetPlayersOfJobs()) do
            xPlayerJob.triggerEvent("fanca_jail:removeEscaping", playerId)
        end

        --------------------------------------------------------------------------------------------------------
        -- For testing
        -- local xPlayers = ESX.GetPlayers()
        -- for i=1, #xPlayers do
        --     Wait(100)
        --     local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        --     xPlayer.triggerEvent("fanca_jail:removeEscaping", playerId)
        -- end
        --------------------------------------------------------------------------------------------------------

        Debug(("The player %s (%s) is escaped from the prison."):format(identifier, playerId))
    end

    if not dontSave then
        MySQL.update('UPDATE users SET jail_escaping = ? WHERE identifier = ?', {tonumber(state), identifier})
    end
end
exports('setEscaping', setEscaping)

function unJail(identifier, outsideThePrison)
    if not JailCache[identifier] then return end
    JailCache[identifier] = nil
    MySQL.update('UPDATE users SET jail_time = ? WHERE identifier = ?', {0, identifier})

    local playerId = ESX.GetPlayerFromIdentifier(identifier)?.playerId
    if playerId then
        playerIdentifiers[playerId] = nil
        local inPrisonZone = not outsideThePrison and lib.callback.await('fanca_jail:isPlayerInPrisonZone', playerId)

        lib.callback('fanca_jail:free', playerId, function()
            if inPrisonZone then
                Debug(("The player %s (%s) is now free."):format(identifier, playerId))
                SetEntityCoords(GetPlayerPed(playerId), Config.releasePoint.x, Config.releasePoint.y, Config.releasePoint.z, 0,0,0, false)
            end
        end)
    end
end
exports('unJail', unJail)

function savePlayer(identifier)
    if not JailCache[identifier] then return end

    local affectedRows = MySQL.update.await('UPDATE users SET jail_time = ? WHERE identifier = ?', {JailCache[identifier].seconds, identifier})
    if affectedRows then
        Debug(("Saved %s seconds of jail time of %s."):format(JailCache[identifier].seconds, identifier))
    else
        Debug(("Failed to save %s jail time (%s seconds)."):format(identifier, JailCache[identifier].seconds))
    end
end
exports('savePlayer', savePlayer)

function savePlayers()
	if not next(JailCache) then return end

    for identifier,_ in pairs(JailCache) do
        savePlayer(identifier)
    end
end
exports('savePlayers', savePlayers)