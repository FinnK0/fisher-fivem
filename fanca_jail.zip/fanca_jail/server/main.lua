JailCache = {}
EscapingCache = {}
playerIdentifiers = {}

local function checkForJail(xPlayer)
    if not xPlayer then return end

    local identifier = xPlayer.getIdentifier()

    Wait(1500)
    local responseJailTime = MySQL.query.await('SELECT jail_time FROM users WHERE identifier = ?', {identifier})

    if responseJailTime and responseJailTime[1].jail_time > 0 then
        setJailTime(xPlayer.playerId, responseJailTime[1].jail_time, true)
    else
        local responseJailEscaping = MySQL.query.await('SELECT jail_escaping FROM users WHERE identifier = ?', {identifier})
        if responseJailEscaping and responseJailEscaping[1].jail_escaping then
            setEscaping(xPlayer.playerId, 1, true)
        end
    end
end

AddEventHandler('esx:playerDropped', function(playerId)
    if not playerIdentifiers[playerId] then return end

    savePlayer(playerIdentifiers[playerId])

    if JailCache[playerIdentifiers[playerId]] then
        JailCache[playerIdentifiers[playerId]] = nil
    end

    if EscapingCache[playerIdentifiers[playerId]] then
        EscapingCache[playerIdentifiers[playerId]] = nil

        for _, xPlayerJob in pairs(GetPlayersOfJobs()) do
            xPlayerJob.triggerEvent("fanca_jail:removeEscaping", playerId)
        end
    end

    playerIdentifiers[playerId] = nil
end)

RegisterNetEvent('esx:playerLoaded', function(playerId, xPlayer, isNew)
    checkForJail(xPlayer)

    if lib.table.contains(Config.jobName, xPlayer.getJob().name) then
        if next(EscapingCache) then
            for k,data in pairs(EscapingCache) do
                local playerId = data.playerId
                xPlayer.triggerEvent("fanca_jail:addEscaping", playerId, Player(playerId).state.name, GetEntityCoords(GetPlayerPed(playerId)))
            end
        end
    end
end)

AddEventHandler('onResourceStart', function(resourceName)
    if (cache.resource ~= resourceName) then return end

    local xPlayers = ESX.GetExtendedPlayers()
    for _, xPlayer in pairs(xPlayers) do
        checkForJail(xPlayer)
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (cache.resource ~= resourceName) then return end

    savePlayers()
    setAlarm(false)
end)

RegisterNetEvent("fanca_jail:escaped", function()
    local playerId = source
    if not playerId then return end

    if JailCache[playerIdentifiers[playerId]] then
        -- local outsideThePrison = not lib.callback.await('fanca_jail:isPlayerInPrisonZone', playerId)

        -- if outsideThePrison then
            local distance = #(GetEntityCoords(GetPlayerPed(playerId)) - Config.prisonCenterPoint)
            local isUnJailDistance = distance > Config.unJailDistance

            if isUnJailDistance then
                setEscaping(playerId, 1)
            else
                -- Ban this trash guy
            end
        -- else
            -- Ban this trash guy
        -- end
    else
        -- Ban this trash guy
    end
end)

lib.callback.register('fanca_jail:sendToJail', function(playerId, targetId, seconds)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    if xPlayer then
        if lib.table.contains(Config.jobName, xPlayer.getJob().name) then
            local distance = #(GetEntityCoords(GetPlayerPed(playerId)) - GetEntityCoords(GetPlayerPed(targetId)))
            if distance < 10.0 then
                setJailTime(targetId, seconds)
                return true
            end
        else
            -- Ban this trash guy
        end
    end

    return false
end)