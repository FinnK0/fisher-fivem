lib.addCommand('setprisonalarm', {
    help = 'Set the prison alarm state',
    params = {
        {
            name = 'state',
            type = 'number',
            help = 'true or false',
        }
    },
    restricted = 'group.admin'
}, function(source, args, raw)
    if args.state == 1 then
        setAlarm(true)
    elseif args.state == 0 then
        setAlarm(false)
    else
        TriggerClientEvent("fanca_jail:notify", source, {type="error", description="You have to write 1 (=enable) or 0 (=disable)."})
    end
end)

lib.addCommand('setjailtime', {
    help = 'Set the jail time of a player',
    params = {
        {
            name = 'target',
            type = 'playerId',
            help = 'Target player\'s server id',
        },
        {
            name = 'time',
            type = 'number',
            help = '(in seconds)',
        }
    },
    restricted = 'group.admin'
}, function(source, args, raw)
    setJailTime(args.target, args.time)
end)

lib.addCommand('getjailtime', {
    help = 'Get the jail time of a player',
    params = {
        {
            name = 'target',
            type = 'playerId',
            help = 'Target player\'s server id',
        }
    },
    restricted = 'group.admin'
}, function(source, args, raw)
    local xPlayer = ESX.GetPlayerFromId(args.target)
    if xPlayer then
        local identifier = xPlayer.getIdentifier()
        local cache = JailCache[identifier]
        if cache then
            TriggerClientEvent('ox_lib:notify', source, { type = 'info', description = ("Player %s (%s) is jailed for %s seconds."):format(identifier, args.target, cache.seconds) })
        end
    end
end)

lib.addCommand('setescaping', {
    help = 'Set the escaping from prison state of a player',
    params = {
        {
            name = 'target',
            type = 'playerId',
            help = 'Target player\'s server id',
        },
        {
            name = 'state',
            type = 'number',
            help = '1 (true) or 0 (false)',
        }
    },
    restricted = 'group.admin'
}, function(source, args, raw)
    setEscaping(args.target, args.state)
end)